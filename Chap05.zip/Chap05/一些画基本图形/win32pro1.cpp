/*------------------------------------------------------------
HELLOWIN.C -- Displays "Hello, Windows 98!" in client area
(c) Charles Petzold, 1998
------------------------------------------------------------*/

#include <windows.h>
#include<mmsystem.h>
#pragma comment(lib,"WINMM.LIB")


LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc2(HWND, UINT, WPARAM, LPARAM);

int Nummax = 1000;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{

	static TCHAR szAppName[] = TEXT("HelloWin");
	HWND         hwnd;
	MSG          msg;
	WNDCLASS     wndclass;

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
		MessageBox(NULL, TEXT("This program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow(szAppName,                  // window class name
		TEXT("The Hello Program"), // window caption
		WS_OVERLAPPEDWINDOW | WS_VSCROLL | WS_HSCROLL,        // window style
		CW_USEDEFAULT,              // initial x position
		CW_USEDEFAULT,              // initial y position
		CW_USEDEFAULT,              // initial x size
		CW_USEDEFAULT,              // initial y size
		NULL,                       // parent window handle
		NULL,                       // window menu handle
		hInstance,                  // program instance handle
		NULL);                     // creation parameters

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);


	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC         hdc;
	PAINTSTRUCT ps;
	SCROLLINFO si;
	TEXTMETRIC tm;
	HPEN hpen;
	HBRUSH hBrush;
	POINT pt[] = { {100,100},{130,70},{270,170},{ 300,100 } };
	static int cxChar, cyChar, cxCaps, cxClient, cyClient, iVscrollPos, iMaxWidth;
	int i;
	LPWSTR databuf = new wchar_t;
	LPWSTR datatmp = new wchar_t;
	int tmpint=0;

	switch (message)
	{
	case WM_CREATE:
		hdc = GetDC(hwnd);
		GetTextMetrics(hdc, &tm);
		cxChar = tm.tmAveCharWidth;
		cyChar = tm.tmHeight + tm.tmExternalLeading;
		cxCaps = (tm.tmPitchAndFamily & 1 ? 3 : 2) / 2 * cxChar;
		ReleaseDC(hwnd, hdc);
		return 0;
	case WM_SIZE:
		cxClient = LOWORD(lParam);
		cyClient = HIWORD(lParam);

		return 0;

	case WM_PAINT:
		hdc = BeginPaint(hwnd, &ps);
		SetDCBrushColor(hdc, RGB(255, 0, 0));
		//Rectangle(hdc, 1,1,5,4);
		//Ellipse(hdc, 10, 10, 210, 110);
		//Arc(hdc, 10, 10, 210, 110, 105, 10, 10, 52);
		//Chord(hdc, 10, 10, 210, 110, 105, 10, 10, 52);
		//Pie(hdc, 10, 10, 210, 110, 105, 10, 10, 52);
		hpen = CreatePen(PS_DOT, 1, 0);
		SelectObject(hdc, GetStockObject(BLACK_BRUSH));
		SelectObject(hdc, hpen);
		//SetBkColor(hdc, RGB(255, 0, 0));
		//PolyBezier(hdc, pt, 4);
		//Pie(hdc, 10, 10, 210, 110, 105, 10, 10, 52);
		Polygon(hdc, pt, 6);
		EndPaint(hwnd, &ps);
		DeleteObject(hpen);
		DeleteObject(SelectObject(hdc, WHITE_BRUSH));
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
