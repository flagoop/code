#include"stdafx.h"
#include"commdlg.h"

static OPENFILENAME	ofn = {};

WCHAR	pFile_path_Buff[260];
void ofnInit(HWND hwnd)
{
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hwnd;
	ofn.lpstrFile = pFile_path_Buff;
	// Set lpstrFile[0] to '\0' so that GetOpenFileName does not  
	// use the contents of pFile_path_Buff to initialize itself. 
	ofn.lpstrFile[0] = '\0';
	ofn.nMaxFile = sizeof(pFile_path_Buff);
	ofn.lpstrFilter = L"All\0*.*\0Text\0*.TXT\0";
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = NULL;
}

BOOL FileSave(HWND hwndDlg)
{
	HANDLE		hFile;
	LPWSTR		pwBuff;
	LPSTR		paBuff;
	int			ibyLength;

	ofn.Flags = OFN_OVERWRITEPROMPT;
	GetSaveFileName(&ofn);
	if (INVALID_HANDLE_VALUE == (hFile = CreateFile(pFile_path_Buff, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL)))
	{
		MessageBox(hwndDlg, L"create file error!", L"info", 0);
		return FALSE;
	}
	ibyLength=GetWindowTextLength(hwndDlg);
	paBuff = (LPSTR)malloc(ibyLength);
	ZeroMemory(paBuff, ibyLength);
	//paBuff[ibyLength+1] = '\0';
	GetWindowTextA(hwndDlg, paBuff, ibyLength+1);//����Ҫ��ʵ���ֽ�����һ���ֽ�

	WriteFile(hFile, paBuff, ibyLength, NULL, NULL);
	CloseHandle(hFile);

	return TRUE;
}


BOOL FileOpen(HWND hwndDlg)
{
    BOOL            bOpened=false;
    int             iFileSize=0;
    DWORD           dwReaded;
    HANDLE          hFile;
	LPWSTR			pwText;
	LPSTR			paText;
	LPWSTR			pw;
	LPSTR			pa;
	LPWSTR			pBuff=NULL;
	LPBOOL			pb = FALSE;
	int				ibyLength;
	int				iTEST;
	//TCHAR			szBuff[1000] = { 0 };
	

	/*
    bOpened=GetOpenFileName(&ofn);
	if (bOpened)
	{
		wsprintf(szBuff, L"lpstrFile=%s\r\n lStructSize=%d\nlpstrFilter=%s\nnMaxFile=%d\n", ofn.lpstrFile, ofn.lStructSize, ofn.lpstrFile, ofn.nMaxFile);
		SetWindowText(hwndDlg, szBuff);
	}
	else
		MessageBox(hwndDlg, L"bOpened is error", L"info", 0);
	*/

	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

	bOpened = GetOpenFileName(&ofn);
	

	
    if(bOpened)
    {

        if(INVALID_HANDLE_VALUE==(hFile=CreateFile(pFile_path_Buff,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL)))
        {
            MessageBox(hwndDlg,TEXT("open file failed"),NULL,0);
            return false;
        }
        iFileSize=GetFileSize(hFile,NULL);
        pBuff=(LPWSTR)malloc(iFileSize+2);
		ZeroMemory(pBuff, iFileSize+2);
		
        ReadFile(hFile,pBuff,iFileSize,&dwReaded,NULL);
		//pBuff[iFileSize] =0x00;
	

		//free(pBuff);
		iTEST = 1;

		//if the filetext is ascii?
		if (pBuff[0] != 0xFEFF)
		{

			paText = (LPSTR)malloc(iFileSize + 1);
			paText[iFileSize] = '\0';
			SetFilePointer(hFile, FILE_BEGIN, NULL, NULL);
			ReadFile(hFile, paText, iFileSize, &dwReaded, NULL);
			SetWindowTextA(hwndDlg, paText);
			free(paText);
			
			paText = nullptr;
			pBuff = nullptr;
			CloseHandle(hFile);
			ZeroMemory(pFile_path_Buff, MAX_PATH);

			return true;
		}
		MessageBox(hwndDlg, L"is unicode", L"info", 0);
		pw = pBuff;
		pw++;
		SetWindowText(hwndDlg, pw);
		free(pBuff);
		pw = NULL;
		pBuff = NULL;
		ZeroMemory(pFile_path_Buff, MAX_PATH);
		CloseHandle(hFile);


		/*
		//����ȡ����unicode����(����ָ����˫�ֽڵ� ����utf-8)���ı�ʱ������ת��Ϊascii ��Ȼ ������ĵ������ģ�ת��������
		pw = pBuff;
		pw++;	//
		ibyLength = WideCharToMultiByte(CP_ACP, 0,pw, -1, NULL, 0, NULL, NULL);
		//ibyLength -= 2;
		paText = (LPSTR)malloc(ibyLength);
		ZeroMemory(paText, ibyLength);
		paText[ibyLength-1] = '\0';

		WideCharToMultiByte(CP_ACP, 0, pw, -1, paText, ibyLength, NULL, NULL);
		SetWindowTextA(hwndDlg, paText);
		iTEST = 1;
		free(pBuff);
		free(paText);
		ZeroMemory(pFile_path_Buff,MAX_PATH);
		pa = NULL;
		pw = NULL;
		paText = NULL;
		pBuff = NULL;
		*/
	
		

		/*
		//test ascii text
		WideCharToMultiByte(CP_ACP, 0, pBuff, -1, paText, iFileSize / 2, NULL, NULL);
		SetWindowTextA(hwndDlg, paText);
		*/
		/*
		paText = (LPSTR)malloc(iFileSize + 1);
		ZeroMemory(paText, iFileSize + 1);
		paText[iFileSize] = '\0';
		*/
		
		/*
		if (pBuff[0] == 0xFEFF)
		{
			MessageBox(hwndDlg, L"is unicode", L"info", 0);
			pw = pBuff;
		}
			
		else
		{
			paText = (LPSTR)malloc(iFileSize + 2);
			MessageBox(hwndDlg, L"is ascii", L"info", 0);
			ZeroMemory(paText, iFileSize + 2);
			for (int i = 0,j=0; i < iFileSize; i++,j++)
			{
				paText[i] = BYTE(pBuff[j]);
				paText[++i] = BYTE(pBuff[j] >> 8);
				
			}
			paText[iFileSize] = '\0';
			
			pwText = (LPWSTR)malloc(iFileSize + 1);
			ZeroMemory(pwText, iFileSize + 1);
			MultiByteToWideChar(CP_UTF8, 0, paText, -1, pwText, iFileSize);
			pwText[iFileSize] = '\0';
			pw = pwText;
		}
		
		SetWindowText(hwndDlg, pw);

		*/
    }
    return true;
}

