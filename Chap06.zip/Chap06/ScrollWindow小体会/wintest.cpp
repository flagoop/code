/*--------------------------------------------------------
KEYVIEW2.C -- Displays Keyboard and Character Messages
(c) Charles Petzold, 1998
--------------------------------------------------------*/

#include <windows.h>

int NUMBERMAX = 1000;
size_t	cntPerson = 100;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

struct Person
{
	TCHAR	zname[10] = { 0 };
	int		zage;

}per, arrPer[5];
Person *pPer = (Person*)malloc(sizeof(Person) * 100);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT("KeyView2");
	HWND         hwnd;
	MSG          msg;
	WNDCLASS     wndclass;

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
		MessageBox(NULL, TEXT("This program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow(szAppName, TEXT("Keyboard Message Viewer #2"),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL);

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}
void initPer()
{
	Person *pPertmp=pPer;
	for (size_t i = 0; i < cntPerson; i++)
	{
//		lstrcpy(arrPer[i].zname, L"jjj");
		lstrcpy(pPertmp->zname, L"jjj");
		pPertmp->zage = i;
		++pPertmp;
	}
}
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	static RECT rt;
	HDC hdc;
	TEXTMETRIC tm;
	static int cxClient, cyClient, cxClientMax, cyClientMax, cxChar, cyChar, cxCaps;
	TCHAR szBuffer[50] = { 0 };
	TCHAR szTitle[] = L"Name                          Age         Address                           Tel.";
	Person *ptmp = pPer;
	static int ilastline, ival, ilinemax;
		

	switch (msg)
	{
	case WM_CREATE:
		cxClientMax = GetSystemMetrics(SM_CXMAXIMIZED);
		cyClientMax = GetSystemMetrics(SM_CYMAXIMIZED);
		initPer();
		return 0;

	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_DOWN:
			ilastline = cyClient / cyChar - 1;
			ScrollWindow(hWnd, 0, -cyChar, 0,0);	//����ǰ�Ŀͻ��������ݣ����أ����Ʋ�ȫ��������һ��cyChar��Ԫ���Ƶ�������һ����Ԫ�����ݣ�
													//���������һ�е����ݣ���ʱ��wm_paint�����ֻ��Ҫ�޸����һ�е����ݼ���ʵ���������Ϲ���Ч��
													//ScrollWindow���Ա�֤wm_paint����ˢ�����еĸĶ�������ݣ���� ��ʾ�ٶ�

			break;
		default:
			break;
		}
		return 0;

	case WM_SIZE:
		hdc = GetDC(hWnd);
		cxClient = LOWORD(lParam);
		cyClient = HIWORD(lParam);
		GetTextMetrics(hdc, &tm);
		cxChar = tm.tmAveCharWidth;
		cxCaps = (tm.tmPitchAndFamily & 1 ? 3 : 2) / 2 * cxChar;
		cyChar = tm.tmHeight + tm.tmExternalLeading;
		
		ilinemax = cyClient / cyChar;

		rt.left = 0;
		rt.top = cyChar;
		rt.right = cxClient;
		rt.bottom = cyClient;

		
		ReleaseDC(hWnd, hdc);
		return 0;

	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);

		//TextOut(hdc, 0, (ilastline-1)*cyChar, szBuffer, wsprintf(szBuffer, L"%d", ilastline));

		
		for (size_t i = ilastline; i < cyClient/cyChar; i++)
		{
			TextOut(hdc, 0, cyChar*(i), szBuffer, wsprintf(szBuffer, L"%d", ival++));
		}



		EndPaint(hWnd, &ps);
		return 0;

	case WM_DESTROY:
		delete pPer;
		PostQuitMessage(0);
		return 0;

	}

	return DefWindowProc(hWnd, msg, wParam, lParam);

}
