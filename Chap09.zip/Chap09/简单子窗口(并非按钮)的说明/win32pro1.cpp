/*-------------------------------------------------
CHECKER3.C -- Mouse Hit-Test Demo Program No. 3
(c) Charles Petzold, 1998
-------------------------------------------------*/

#include <windows.h>
#include<windowsx.h>

#define DIVISIONS 5

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ChildProc(HWND, UINT, WPARAM, LPARAM);

TCHAR szChildClass[] = TEXT("Checker3_Child");

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT("Checker3");
	HWND         hwnd;
	MSG          msg;
	WNDCLASS     wndclass;

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
		MessageBox(NULL, TEXT("Program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}
	
	//child windows register
	wndclass.lpfnWndProc = ChildProc;
	wndclass.lpszClassName = szChildClass;
	RegisterClass(&wndclass);

	hwnd = CreateWindow(szAppName, TEXT("Checker3 Mouse Hit-Test Demo"),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL);

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	HDC				hdc;
	static HWND		hChild;
	static int		cxClient, cyClient;
	TCHAR			szBuf[10] = { 0 };

	switch (msg)
	{
	case WM_CREATE:
		hChild = CreateWindow(szChildClass, L"CW", WS_CHILDWINDOW | WS_VISIBLE,
			0, 0, 0, 0, hwnd, (HMENU)1, NULL, NULL);
		return 0;
	case WM_SIZE:
		MoveWindow(hChild, 10, 10, 130, 60, TRUE);
		hdc = GetDC(hwnd);
		TextOut(hdc, 0, 0, L"kkk", 3);
		//��10 10 ������� �㣬�Ѿ������Ӵ��ڣ�ֻ��û����ʾ�������� ������EEE�Ǳ����ǵģ�������
		TextOut(hdc, 10, 10, L"EEE", 3);

		ReleaseDC(hwnd, hdc);
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	
	}

	return DefWindowProc(hwnd, msg, wparam, lparam);
}

LRESULT CALLBACK ChildProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	HDC				hdc;
	PAINTSTRUCT		ps;
	static RECT		rt;

	switch (msg)
	{

	case WM_PAINT:
		hdc = BeginPaint(hwnd, &ps);
		
		GetClientRect(hwnd, &rt);//�Ӵ��ڵı߿����� 
		//Rectangle�е����� 0 0 ���÷�Χ�����Ӵ��ڵı߿��С  
		//wndproc���Ѿ�ָ���Ӵ��ڱ߿�����Ϊ10,10,130,60 (movewindow)��
		//���������0 0 ָ�ľ����Ӵ������� 10 10 ����� 
		Rectangle(hdc, 0, 0, rt.right, rt.bottom);
		EndPaint(hwnd,&ps);
		return 0;
	case WM_LBUTTONDOWN:
		hdc = GetDC(hwnd);
		MoveToEx(hdc, rt.left, rt.top, NULL);
		LineTo(hdc, rt.right, rt.bottom);
		ReleaseDC(hwnd, hdc);
		return 0;
	}
	return DefWindowProc(hwnd, msg, wparam, lparam);
}