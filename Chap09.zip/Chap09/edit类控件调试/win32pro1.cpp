﻿/*-------------------------------------------------------
POPPAD1.C -- Popup Editor using child window edit box
(c) Charles Petzold, 1998
-------------------------------------------------------*/

#include <windows.h>

#define ID_EDIT     1

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

TCHAR szAppName[] = TEXT("PopPad1");

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{
	HWND     hwnd;
	MSG      msg;
	WNDCLASS wndclass;

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = CreateSolidBrush(0);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
		MessageBox(NULL, TEXT("This program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow(szAppName, szAppName,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL);

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HWND hwndEdit,hwndBtn1,hwndBtn2,hwndBtn3;
	HDC			hdc=GetDC(hwnd);
	TCHAR		szbuf[100] = { 0 };
	INT			iStart, iEnd;
	int			iNumber,iLineIndex;
	int			iLineLength;

	switch (message)
	{
	case WM_CREATE:
		hwndEdit = CreateWindow(TEXT("edit"), NULL,
			WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL |
			WS_BORDER | ES_LEFT | ES_MULTILINE |
			ES_AUTOHSCROLL | ES_AUTOVSCROLL,
			0, 0, 0, 0, hwnd, (HMENU)ID_EDIT,
			((LPCREATESTRUCT)lParam)->hInstance, NULL);
		hwndBtn1 = CreateWindow(L"button", L"gettext", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			0, 0, 0, 0, hwnd, (HMENU)10, NULL, NULL);
		hwndBtn2 = CreateWindow(L"button", L"replacetext", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			0, 0, 0, 0, hwnd, (HMENU)11, NULL, NULL);
		hwndBtn3 = CreateWindow(L"button", L"othertools", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			0, 0, 0, 0, hwnd, (HMENU)12, NULL, NULL);

		return 0;

	case WM_SETFOCUS:
		SetFocus(hwndEdit);
		return 0;

	case WM_SIZE:
		MoveWindow(hwndEdit, 0, 0, LOWORD(lParam)/2, HIWORD(lParam), TRUE);
		MoveWindow(hwndBtn1, LOWORD(lParam) - 200, 0, 140, 60, TRUE);
		MoveWindow(hwndBtn2, LOWORD(lParam) - 200,60, 140, 60, TRUE);
		MoveWindow(hwndBtn3, LOWORD(lParam) - 200, 120, 140, 60, TRUE);
		EnableWindow(hwndBtn3, FALSE);
		return 0;

	case WM_COMMAND:
		if (LOWORD(wParam) == ID_EDIT)
		{
			if (HIWORD(wParam) == EN_ERRSPACE ||
				HIWORD(wParam) == EN_MAXTEXT)
			{
				MessageBox(hwnd, TEXT("Edit control out of space."),
					szAppName, MB_OK | MB_ICONSTOP);
			}
			if (HIWORD(wParam) == EN_CHANGE)
			{
				EnableWindow(hwndBtn3, TRUE);
			}
		}
			
		if (LOWORD(wParam) == 10)
		{
			GetWindowText(hwndEdit, szbuf, 100);
			//hdc== GetDC(hwnd);
			TextOut(hdc, LOWORD(lParam) - 200, 200, szbuf, lstrlen(szbuf));
			ReleaseDC(hwnd, hdc);
		}

		if (LOWORD(wParam) == 11)
		{
			//这里的iStart和iEnd是根据鼠标所选择的高亮字段为前提的，高亮的起始就是iStart
			//高亮的结束就是 iEnd
			SendMessage(hwndEdit, EM_GETSEL, (WPARAM)&iStart, (LPARAM)&iEnd);
			wsprintf(szbuf, L"%d:%d", iStart,iEnd);
			MessageBox(hwnd, szbuf, L"info", 0);
			//SetFocus(hwndEdit);
			//SendMessage(hwndEdit, EM_SETSEL, iStart,iEnd);
			//SendMessage(hwndEdit, WM_CUT, 0, 0);
			//SendMessage(hwndEdit, EM_REPLACESEL, 0,(LPARAM)TEXT("ppp"));
		}

		if (LOWORD(wParam) == 12)
		{
			/* //统计行数
			iNumber = SendMessage(hwndEdit, EM_GETLINECOUNT, 0, 0);
			wsprintf(szbuf, TEXT("lines: %d"), iNumber);
			MessageBox(hwnd, szbuf, TEXT("info"), 0);
			*/
			
			
			//iLineIndex = SendMessage(hwndEdit, EM_LINEINDEX, 1, 0);//第2行第一个字符是占edit里所有字符的第几个位置
			//iLineIndex = SendMessage(hwndEdit, EM_LINEINDEX, 2, 0);	//第3行字一个字符所占index
			iLineIndex = SendMessage(hwndEdit, EM_LINEINDEX, -1, 0);//光标所在行

			wsprintf(szbuf, TEXT("line index: %d"), iLineIndex);
			MessageBox(hwnd, szbuf, TEXT("info"), 0);
			
			
			/*
			iLineLength = SendMessage(hwndEdit, EM_LINELENGTH, -1, 0);
			wsprintf(szbuf, TEXT("line length: %d"), iLineLength);
			MessageBox(hwnd, szbuf, TEXT("info"), 0);
			*/
			
			/*
			szbuf[0]=100;	//em_getline必须要先将szbuf[0]设置为接收line的大小 
			//wparam 0表示第一行 ，而且只能从0开始 zero-based
			//iLineLength = SendMessage(hwndEdit, EM_GETLINE,0, (LPARAM)szbuf);
			iLineLength = SendMessage(hwndEdit, EM_GETLINE,1, (LPARAM)szbuf);

			MessageBox(hwnd, szbuf, TEXT("info"), 0);
			*/

		}
		return 0;

	case WM_DESTROY:
		DeleteObject((HBRUSH)SetClassLong(hwnd, GCL_HBRBACKGROUND,
				(LONG) GetStockObject(WHITE_BRUSH)));
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
