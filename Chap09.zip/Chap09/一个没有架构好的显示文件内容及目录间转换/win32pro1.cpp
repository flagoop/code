﻿/*---------------------------------------------
HEAD.C -- Displays beginning (head) of file
(c) Charles Petzold, 1998
---------------------------------------------*/

#include <windows.h>

#define ID_LIST     1
#define ID_TEXT     2

#define MAXREAD     8192
#define DIRATTR     (DDL_READWRITE | DDL_READONLY | DDL_HIDDEN | DDL_SYSTEM | \
                     DDL_DIRECTORY | DDL_ARCHIVE  | DDL_DRIVES)
#define DTFLAGS     (DT_WORDBREAK | DT_EXPANDTABS | DT_NOCLIP | DT_NOPREFIX)

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ListProc(HWND, UINT, WPARAM, LPARAM);

WNDPROC OldList;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT("head");
	HWND         hwnd;
	MSG          msg;
	WNDCLASS     wndclass;

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
		MessageBox(NULL, TEXT("This program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow(szAppName, TEXT("head"),
		WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
		CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL);

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static BOOL     bValidFile;
	//static TCHAR    buffer[MAXREAD];
	static TCHAR	*pBuffer;
	static HWND     hwndList, hwndText;
	static RECT     rect;
	static TCHAR    szFile[MAX_PATH + 1];
	HANDLE          hFile;
	HDC             hdc;
	int             i, cxChar, cyChar;
	PAINTSTRUCT     ps;
	TCHAR           szBuffer[MAX_PATH + 1];
	static DWORD	fileSize, readSize;

	switch (message)
	{
	case WM_CREATE:
		cxChar = LOWORD(GetDialogBaseUnits());
		cyChar = HIWORD(GetDialogBaseUnits());

		rect.left = 20 * cxChar;
		rect.top = 3 * cyChar;

		hwndList = CreateWindow(TEXT("listbox"), NULL,
			WS_CHILDWINDOW | WS_VISIBLE | LBS_STANDARD,
			cxChar, cyChar * 3,
			cxChar * 13 + GetSystemMetrics(SM_CXVSCROLL),
			cyChar * 10,
			hwnd, (HMENU)ID_LIST,
			(HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE),
			NULL);

		GetCurrentDirectory(MAX_PATH + 1, szBuffer);

		hwndText = CreateWindow(TEXT("static"), szBuffer,
			WS_CHILDWINDOW | WS_VISIBLE | SS_LEFT,
			cxChar, cyChar, cxChar * MAX_PATH, cyChar,
			hwnd, (HMENU)ID_TEXT,
			(HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE),
			NULL);

		/*获得一个wndproc类型的指向hwndList控件的值是为了在hwndList子窗口过程中，
			用于将键盘处理结果返回给hwndList控件
			也可以理解为 为hwndList定义一个子窗口，并为返回hwndList提供一个返回地址
			*/
		OldList = (WNDPROC)SetWindowLong(hwndList, GWL_WNDPROC,
			(LPARAM)ListProc);	

		SendMessage(hwndList, LB_DIR, DIRATTR, (LPARAM)TEXT("*.*"));
		return 0;
	case WM_SIZE:
		rect.right = LOWORD(lParam);
		rect.bottom = HIWORD(lParam);
		return 0;

	case WM_COMMAND:
		hdc = GetDC(hwnd);
		if (LOWORD(wParam) == ID_LIST && HIWORD(wParam) == LBN_DBLCLK)
		{
			if (LB_ERR == (i = SendMessage(hwndList, LB_GETCURSEL, 0, 0)))
			{
				MessageBox(hwnd, TEXT("lb_err"), TEXT("info"), 0);
				break;
			}
			SendMessage(hwndList, LB_GETTEXT, i, (LPARAM)&szBuffer);
			lstrcpy(szFile, szBuffer);
			if ((hFile = CreateFile(szBuffer, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
				0, NULL)) == INVALID_HANDLE_VALUE)
			{
				//MessageBox(hwnd, szBuffer+1, L"info", 0);
				szBuffer[lstrlen(szBuffer) - 1] = '\0';
				if (!SetCurrentDirectory(szBuffer + 1))	//判断是否子目录，=0不是，则直接作盘符处理
				{
					szBuffer[3] = ':';
					szBuffer[4] = '\\';
					szBuffer[5] = '\0';
					//MessageBox(hwnd, szBuffer+2, L"info", 0);
					
					SetCurrentDirectory(szBuffer + 2);
					SendMessage(hwndList, LB_RESETCONTENT, 0, 0);
					SendMessage(hwndList, LB_DIR, DIRATTR, (LPARAM)TEXT("*.*"));
					GetCurrentDirectory(MAX_PATH, szBuffer);
					SetWindowText(hwndText, (szBuffer + 2));
					break;
				}
				SendMessage(hwndList, LB_RESETCONTENT, 0, 0);
				SendMessage(hwndList, LB_DIR, DIRATTR, (LPARAM)TEXT("*.*"));
				GetCurrentDirectory(MAX_PATH, szBuffer);
				SetWindowText(hwndText, szBuffer);
				break;
			}
			//MessageBox(hwnd, szBuffer, L"info", 0);

			fileSize = GetFileSize(hFile, NULL);
			pBuffer = (TCHAR*)calloc(fileSize, sizeof(TCHAR));
			if (ReadFile(hFile, pBuffer, fileSize, &readSize, NULL) == 0)
			{
				pBuffer = nullptr;
				MessageBox(hwnd, L"readfile error", L"info", 0);
				break;
			}

			pBuffer[fileSize + 1] = 0;
			CloseHandle(hFile);
			GetCurrentDirectory(MAX_PATH, szBuffer);
			SetWindowText(hwndText, szBuffer);

			InvalidateRect(hwnd, &rect, true);

		}

		return 0;



	case WM_PAINT:

		hdc = BeginPaint(hwnd, &ps);
		//TextOut(hdc, 250, 50, pBuffer, fileSize);
		SelectObject(hdc, GetStockObject(SYSTEM_FIXED_FONT));
		SetTextColor(hdc, GetSysColor(COLOR_BTNTEXT));
		SetBkColor(hdc, GetSysColor(COLOR_BTNFACE));

		if (pBuffer)
		{
			if (pBuffer[0] == 0xFF && pBuffer[1] == 0xFE)
			{
				DrawText(hdc, pBuffer, readSize, &rect, DTFLAGS);
			}
			else
			{
				DrawTextA(hdc, (LPCSTR)pBuffer, readSize, &rect, DTFLAGS);
			}
		}
		EndPaint(hwnd, &ps);
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
LRESULT CALLBACK ListProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_KEYDOWN:
		if (wParam == VK_RETURN)
		{
			/*发送给父窗口一个消息，(LOWORD)wparam=控件的编号 这里是id_list
				(HIWORD)wparam=控件的内部通知码 这里是 LBN_DBLCLK
				lparam存放的是这个子窗口的hwnd
			*/
			SendMessage(GetParent(hwnd), WM_COMMAND, MAKELONG(ID_LIST, LBN_DBLCLK), (LPARAM)hwnd);
		}
		//MessageBox(hwnd, L"ListProc", L"info", 0);
		break;
	default:
		break;
	}
	return CallWindowProc(OldList, hwnd, message, wParam, lParam);
}
