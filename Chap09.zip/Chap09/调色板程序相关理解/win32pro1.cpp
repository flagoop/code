﻿/*----------------------------------------
COLORS1.C -- Colors Using Scroll Bars
(c) Charles Petzold, 1998
----------------------------------------*/

#include <windows.h>
#include<windowsx.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ScrollProc(HWND, UINT, WPARAM, LPARAM);

int     idFocus;
WNDPROC OldScroll[3];

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT("Colors1");
	HWND         hwnd;
	MSG          msg;
	WNDCLASS     wndclass;

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = CreateSolidBrush(0);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
		MessageBox(NULL, TEXT("This program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow(szAppName, TEXT("Color Scroll"),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL);

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static COLORREF crPrim[3] = { RGB(255, 0, 0), RGB(0, 255, 0),
		RGB(0, 0, 255) };
	static HBRUSH   hBrush[3], hBrushStatic;
	static HWND     hwndScroll[3], hwndLabel[3], hwndValue[3], hwndRect;
	static int      color[3], cyChar;
	static RECT     rcColor;
	static TCHAR *  szColorLabel[] = { TEXT("Red"), TEXT("Green"),
		TEXT("Blue") };
	//HINSTANCE       hInstance;	//不太了解这个的用途
	int             i, cxClient, cyClient;
	TCHAR           szBuffer[10];
	HDC             hdc;
	switch (message)
	{
	case WM_CREATE:
		hwndRect = CreateWindow(TEXT("static"), NULL, WS_CHILDWINDOW | WS_VISIBLE | SS_WHITERECT,
			0, 0, 0, 0, hwnd, (HMENU)9, NULL, NULL);
		for (i = 0; i < 3; ++i)
		{
			hwndScroll[i] = CreateWindow(TEXT("scrollbar"), NULL,
				WS_CHILDWINDOW | WS_VISIBLE | WS_TABSTOP | SBS_VERT,
				0, 0, 0, 0, hwnd, (HMENU)i,NULL, NULL);

			hBrush[i] = CreateSolidBrush(crPrim[i]);
			SetScrollRange(hwndScroll[i], SB_CTL, 0, 255, TRUE);
			SetScrollPos(hwndScroll[i], SB_CTL, 0, TRUE);

			hwndValue[i] = CreateWindow(TEXT("static"), L"0", 
				WS_CHILDWINDOW | WS_VISIBLE | SS_CENTER,
				0, 0, 0, 0, hwnd, (HMENU)(i+3), NULL, NULL);

			hwndLabel[i] = CreateWindow(TEXT("static"), szColorLabel[i],
				WS_CHILDWINDOW | WS_VISIBLE | SS_CENTER,
				0, 0, 0, 0, hwnd, (HMENU)(i + 6), NULL, NULL);

			OldScroll[i] = (WNDPROC)SetWindowLong(hwndScroll[i], GWL_WNDPROC,
				(LONG)ScrollProc);
		}
		hBrushStatic =CreateSolidBrush( GetSysColor(COLOR_BTNHIGHLIGHT));
		//hBrushStatic = CreateSolidBrush(RGB(140,120,0));
		return 0;

	case WM_SIZE:
		cxClient = GET_X_LPARAM(lParam);
		cyClient = GET_Y_LPARAM(lParam);
		MoveWindow(hwndRect, 0, 0, cxClient / 2, cyClient, TRUE);
		SetRect(&rcColor, cxClient / 2, 0, cxClient, cyClient);
		for ( i = 0; i < 3; i++)
		{
			MoveWindow(hwndScroll[i], 30 + 60 * i, 30, 40, 200, TRUE);
			MoveWindow(hwndValue[i], 30 + 60 * i, 235, 40, 20, TRUE);
			MoveWindow(hwndLabel[i], 30 + 60 * i, 10, 40, 20, TRUE);
		}
		SetFocus(hwnd);

		return 0;

	case WM_VSCROLL:
		i = GetWindowLong((HWND)lParam, GWL_ID);
		switch (LOWORD(wParam))
		{
		case SB_LINEUP:
			color[i] = max(0, color[i] - 1);
			break;
		case SB_LINEDOWN:
			color[i] = min(255, color[i] + 1);
			break;
		case SB_THUMBPOSITION:	//滑动并释放鼠标后，再设置新位置
		case SB_THUMBTRACK:		//滑动中就设置新位置
			color[i] = HIWORD(wParam);
			break;

		}
		SetScrollPos(hwndScroll[i], SB_CTL, color[i], TRUE);
		wsprintf(szBuffer, L"%d", color[i]);
		SetWindowText(hwndValue[i], szBuffer);
		DeleteObject((HBRUSH)SetClassLong(hwnd, GCL_HBRBACKGROUND,
			(LONG)CreateSolidBrush(RGB(color[0], color[1], color[2]))));

		//这里没有处理wm_paint消息 ，而是直接交给了defwindowproc，在defwindowproc里，
		//会产生一条wm_paint消息 ，但默认的wm_paint只生成begingpaint(...)和endpaint(...)
		//在invalidaterect里，设置了TRUE 探险原先背景的选项，所以在begingpaint()里会额外生成
		//一条wm_erasebkgnd()消息来擦除背景 ,windows这个时候就会用上条语句定义的画刷重新填充该背景
		InvalidateRect(hwnd, &rcColor, TRUE);
		return 0;
	case WM_CTLCOLORSCROLLBAR:
		i = GetWindowLong((HWND)lParam, GWL_ID);
		return (LRESULT)hBrush[i];	//返回值填充整个scrollbar控件

	case WM_CTLCOLORSTATIC:
		i = GetWindowLong((HWND)lParam, GWL_ID);
		if (i >= 3 && i <= 8)
		{
		//设置的是静态控件中文本部分的前景和背景颜色，但控件的其余部分颜色由return返回值填充
			SetTextColor((HDC)wParam, crPrim[i%3]);
			SetBkColor((HDC)wParam, RGB(255,255,255));
			return (LRESULT)hBrushStatic;
		}
		break;

		
	case WM_SETFOCUS:
		SetFocus(hwndScroll[idFocus]);
		return 0;
		
	case WM_DESTROY:
		for (i = 0; i < 3; i++)
		{
			DeleteBrush(hBrush[i]);

		}
		DeleteObject((HBRUSH)SetClassLong(hwnd,GCL_HBRBACKGROUND,
				(LONG) GetStockBrush(WHITE_BRUSH)));
		//设置新画刷，返回旧画刷，则deleteobject删除的就是旧画刷
		DeleteBrush(hBrushStatic);
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}

LRESULT CALLBACK ScrollProc(HWND hwnd, UINT message,
	WPARAM wParam, LPARAM lParam)
{
	int id = GetWindowLong(hwnd, GWL_ID);

	switch (message)
	{
		
	case WM_KEYDOWN:
		if (wParam == VK_TAB)
			SetFocus(GetDlgItem(GetParent(hwnd),
			(id + (GetKeyState(VK_SHIFT) < 0 ? 2 : 1)) % 3));
	//建议单一表达式用括号括起来,这里(GetKeyState(VK_SHIFT) < 0 ? 2 : 1)括起来算一个整体
		break;
		/*
	case WM_LBUTTONDOWN:
		MessageBox(hwnd, L"lbuttondown", L"info", 0);
		break;*/
	case WM_SETFOCUS:
		idFocus = id;//全局idFocus设置
		break;
	}
	return CallWindowProc(OldScroll[id], hwnd, message, wParam, lParam);
	//返回给 windows,然后让os用callwindowproc调用oldscroll[id]所在的wndproc
	//这里这个函数地址是LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
	//因为在wndproc里已经用oldscroll[i]=(WNDPROC)setwindowlong(...)
	//这里setwindowlong的返回值是根据内部参数来确定的，这里的参数是gwl_wndproc 设置新窗口过程
	//所以，相对 的setwindowlong的返回值 就是设置新窗口地址前的原地址，即WndProc(...)
}

