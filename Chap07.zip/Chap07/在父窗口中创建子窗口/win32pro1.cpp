/*-------------------------------------------------
CHECKER3.C -- Mouse Hit-Test Demo Program No. 3
(c) Charles Petzold, 1998
-------------------------------------------------*/

#include <windows.h>

#define DIVISIONS 5

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ChildWndProc(HWND, UINT, WPARAM, LPARAM);

TCHAR szChildClass[] = TEXT("Checker3_Child");

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT("Checker3");
	HWND         hwnd;
	MSG          msg;
	WNDCLASS     wndclass;

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
		MessageBox(NULL, TEXT("Program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}

	//wndclass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	wndclass.lpfnWndProc = ChildWndProc;
	wndclass.cbWndExtra = sizeof(long);
	wndclass.hIcon = NULL;
	wndclass.lpszClassName = szChildClass;

	RegisterClass(&wndclass);

	hwnd = CreateWindow(szAppName, TEXT("Checker3 Mouse Hit-Test Demo"),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL);

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//static HWND hwndChild[DIVISIONS][DIVISIONS];
	static HWND hwndChild[DIVISIONS];
	int         cxClient,cyClient,cxBlock, cyBlock, x, y;
	int i;
	switch (message)
	{
	case WM_CREATE:
		for ( i = 0; i < DIVISIONS; i++)
		{
			//����DIVISIONS��szChildClass������Ĵ��ڣ���ָ��Ϊws_childwindow�Ӵ���
			//һ��CreateWindow�ڷ���ǰ�������Ӧ�Ĵ��ڹ���(����Ĵ��ڹ��̾���
			//ChildWndProc)����һ��wm_create��Ϣ 
			hwndChild[i] = CreateWindow(szChildClass, NULL, WS_CHILDWINDOW |WS_VISIBLE ,
				0, 0, 0, 0, hwnd, NULL,
				(HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE), NULL);
			SetWindowLong(hwndChild[i], 0, i);
		}
		
	
		return 0;

	case WM_SIZE:
		cxClient = LOWORD(lParam);
		cyClient = HIWORD(lParam);
		cxBlock = cxClient / DIVISIONS;
		cyBlock = cyClient / DIVISIONS;
		
		for  (i = 0; i < DIVISIONS; i++)
		{
			//��DIVISIONS���Ӵ����ڸ������е�λ�úʹ�С��������
			MoveWindow(hwndChild[i], i*cxBlock, 0, cxBlock, cyBlock, TRUE);
		}
		
		return 0;

	case WM_LBUTTONDOWN:
		MessageBox(hwnd, L"����˸�����", L"info", 0);
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}

LRESULT CALLBACK ChildWndProc(HWND hwnd, UINT message,
	WPARAM wParam, LPARAM lParam)
{
	HDC         hdc;
	PAINTSTRUCT ps;
	RECT        rect;
	TCHAR szBuf[10] = { 0 };
	long flag;

	switch (message)
	{
	case WM_CREATE:
		SetWindowLong(hwnd, 0, 0);
		return 0;

	case WM_LBUTTONDOWN:
		wsprintf(szBuf, L"������Ӵ��� %ld", GetWindowLong(hwnd, 0));
		MessageBox(hwnd, szBuf, L"info", 0);
		hdc = GetDC(hwnd);
		
		ReleaseDC(hwnd, hdc);
		return 0;

	case WM_PAINT:
		hdc = BeginPaint(hwnd, &ps);

		//���ÿһ���Ӵ��ڽ���߿��С������ createwindow�����ử��ws_childwindow�ı߿�
		GetClientRect(hwnd, &rect);
		Rectangle(hdc, 0, 0, rect.right, rect.bottom);

		EndPaint(hwnd, &ps);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
