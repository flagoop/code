﻿/*----------------------------------------
POPMENU.C -- Popup Menu Demonstration
(c) Charles Petzold, 1998
----------------------------------------*/

#include <windows.h>
#include "resource.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

HINSTANCE hInst;
TCHAR     szAppName[] = TEXT("JJ");
TCHAR     szAppName2[] = TEXT("M2");

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{
	HWND     hwnd;
	MSG      msg;
	WNDCLASS wndclass;

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, szAppName);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName = szAppName;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
		MessageBox(NULL, TEXT("This program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}

	hInst = hInstance;

	hwnd = CreateWindow(szAppName, TEXT("Popup Menu Demonstration"),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL);

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HMENU hMenu;
	static int   idColor[5] = { WHITE_BRUSH,  LTGRAY_BRUSH, GRAY_BRUSH,
		DKGRAY_BRUSH, BLACK_BRUSH };
	static int   iSelection = ID_TEST_1;
	POINT        point;

	switch (message)
	{
	case WM_CREATE:
		//hMenu = LoadMenu(hInst, szAppName);
		//右键弹出菜单只能是某个菜单句柄的第一栏下拉菜单项 这里使用新建的一个菜单资源M2 但只能显示第一栏下拉菜单
		hMenu = LoadMenu(hInst, szAppName2);
		hMenu = GetSubMenu(hMenu, 0);
		return 0;

	case WM_RBUTTONUP:
		point.x = LOWORD(lParam);
		point.y = HIWORD(lParam);
		ClientToScreen(hwnd, &point);

		TrackPopupMenu(hMenu, TPM_RIGHTBUTTON, point.x, point.y,
			0, hwnd, NULL);
		return 0;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{

		case ID_TEST_1:         // Note: Logic below
		case ID_TEST_2:
		case ID_TEST_3:
			CheckMenuItem(hMenu, iSelection, MF_UNCHECKED);
			iSelection = LOWORD(wParam);
			CheckMenuItem(hMenu, iSelection, MF_CHECKED);

			SetClassLong(hwnd, GCL_HBRBACKGROUND, (LONG)
				GetStockObject
				(idColor[LOWORD(wParam) - ID_TEST_1]));

			InvalidateRect(hwnd, NULL, TRUE);
			return 0;

		case ID_OTHER_ABOUT:
			MessageBox(hwnd, TEXT("Popup Menu Demonstration Program\n")
				TEXT("(c) Charles Petzold, 1998"),
				szAppName, MB_ICONINFORMATION | MB_OK);
			return 0;

		case ID_FILE_EXIT:
			SendMessage(hwnd, WM_CLOSE, 0, 0);
			return 0;

		
		}
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
