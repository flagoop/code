﻿/*----------------------------------------
POPMENU.C -- Popup Menu Demonstration
(c) Charles Petzold, 1998
----------------------------------------*/

#include <windows.h>
#include"resource.h"


HMENU hMenu, hMenuPopup, hMenuSub;
WNDPROC	hWndOld;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditProc(HWND, UINT, WPARAM, LPARAM);


HINSTANCE hInst;
TCHAR     szAppName[] = TEXT("M1");

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{
	HWND     hwnd;
	MSG      msg;
	WNDCLASS wndclass;
	HACCEL		hAccele;

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, szAppName);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
	
		MessageBox(NULL, TEXT("This program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}

	hInst = hInstance;

	hwnd = CreateWindow(szAppName, TEXT("Popup Menu Demonstration"),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL);



	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	hAccele = LoadAccelerators(hInst, MAKEINTRESOURCE(IDR_ACCELERATOR1));

	while (GetMessage(&msg, NULL, 0, 0))
	{
		if(!TranslateAccelerator(hwnd,hAccele,&msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);

		}
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//POINT	pt;
	TCHAR	szbuff[100] = { 0 };
	int		iSelect,iEnable;
	static HWND	hEdit;

	switch (message)
	{
	case WM_CREATE:
		hEdit = CreateWindow(L"edit", NULL, ES_AUTOHSCROLL | ES_AUTOVSCROLL | ES_LEFT | ES_MULTILINE |
			WS_CHILD | WS_VISIBLE | WS_BORDER, 0, 0, 0, 0, hwnd, (HMENU)10, hInst, 0);

		hWndOld=(WNDPROC) SetWindowLong(hEdit, GWL_WNDPROC,(LONG) EditProc);
		//
		hMenu = LoadMenu(hInst, MAKEINTRESOURCE(IDR_MENU1));
		SetMenu(hwnd,hMenu);
		hMenuSub = GetSubMenu(hMenu, 1);
		return 0;

	case WM_SIZE:
		MoveWindow(hEdit, 0, 0, LOWORD(lParam), HIWORD(lParam), TRUE);
		return 0;

		/*
	case WM_RBUTTONUP:
		pt.x = LOWORD(lParam);
		pt.y = HIWORD(lParam);
		ClientToScreen(hwnd, &pt);
		TrackPopupMenu(hMenuSub, TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwnd, NULL);
		return 0;
	*/
	case WM_INITMENUPOPUP:
		if (LOWORD(lParam) == 1)
		{
			MessageBox(hwnd, L"initmenupopup", L"info", 0);//如果在加速键中重新定义了Ctrl+C，
			//则我们在用Ctrl+C的时候 就会触发这个wm_initmenupopup，如果没有定义 ，用了windows默认的
			//Ctrl+c则不会触发这条wm_initmenupopup

			/*//一般不去禁止全选
			EnableMenuItem((HMENU)wParam, ID_EDIT_SELECTALL,
				SendMessage(hEdit, WM_GETTEXT, 100,(LPARAM)szbuff) ? MF_ENABLED : MF_GRAYED);
			*/

			EnableMenuItem((HMENU)wParam, ID_EDIT_UNDO, 
					SendMessage(hEdit, EM_CANUNDO, 0, 0) ? MF_ENABLED : MF_GRAYED);
			EnableMenuItem((HMENU)wParam, ID_EDIT_PASTE,
					IsClipboardFormatAvailable(CF_TEXT) ? MF_ENABLED : MF_GRAYED);

			iSelect = SendMessage(hEdit, EM_GETSEL, 0, 0);
			if (LOWORD(iSelect) == HIWORD(iSelect))
			{
				iEnable = MF_GRAYED;
			}
			else
			{
				iEnable = MF_ENABLED;
			}
			EnableMenuItem(hMenu, ID_EDIT_COPY, iEnable);
			EnableMenuItem(hMenu, ID_EDIT_CUT, iEnable);
			EnableMenuItem(hMenu, ID_EDIT_DELTE, iEnable);
			return 0;

		}
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		//menu File
		case ID_FILE_EXIT:
			SendMessage(hwnd, WM_DESTROY, 0, 0);
			break;
		//menu Edit
		case ID_EDIT_UNDO:
			SendMessage(hEdit, WM_UNDO, 0, 0);
			break;
		case ID_EDIT_COPY:
			SendMessage(hEdit, WM_COPY, 0, 0);
			break;
		case ID_EDIT_CUT:
			SendMessage(hEdit, WM_CUT, 0, 0);
			break;
		case ID_EDIT_PASTE:
			SendMessage(hEdit, WM_PASTE, 0, 0);
			break;
		case ID_EDIT_SELECTALL:
			SendMessage(hEdit, EM_SETSEL, 0, -1);
			break;
		case ID_EDIT_DELTE:
			SendMessage(hEdit, WM_CLEAR, 0, 0);
			break;
		}
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}

//
LRESULT CALLBACK EditProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	POINT	pt;
	
	switch (msg)
	{

	/*
		//有个bug 1.弹出窗口的坐标不对 2.弹出菜单中的菜单项有效或者无效并没有同步
	case WM_RBUTTONUP:
		//MessageBox(hwnd, L"EditProc", L"info", 0);
		//SendMessage(hwnd, WM_INITMENUPOPUP, 0,0);//然而它并没有发送出去
		pt.x = LOWORD(lparam);
		pt.x = HIWORD(lparam);
		ClientToScreen(hwnd, &pt);
		TrackPopupMenu(hMenuSub, TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwnd, NULL);
		break;
	*/
		//这个消息 直接捕获屏幕坐标 而不用 clienttoscreen
	case WM_CONTEXTMENU: 
		//MessageBox(hwnd, L"contextmenu", L"info", 0);
		TrackPopupMenu(hMenuSub, TPM_RIGHTBUTTON, LOWORD(lparam),HIWORD(lparam),
				0, hwnd, NULL);

		break;
	}
	return CallWindowProc(hWndOld, hwnd, msg, wparam, lparam);
}