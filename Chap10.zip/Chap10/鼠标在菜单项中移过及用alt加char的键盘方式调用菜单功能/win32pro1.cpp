﻿/*------------------------------------------------------------
HELLOWIN.C -- Displays "Hello, Windows 98!" in client area
(c) Charles Petzold, 1998
------------------------------------------------------------*/

#include <windows.h>
#include"resource.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

HINSTANCE	hInst;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{
	hInst = hInstance;

	static TCHAR szAppName[] = TEXT("HelloWin");
	HWND         hwnd;
	MSG          msg;
	WNDCLASS     wndclass;

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName =szAppName;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
		MessageBox(NULL, TEXT("This program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow(szAppName,                  // window class name
		TEXT("The Hello Program"), // window caption
		WS_OVERLAPPEDWINDOW | WS_VSCROLL | WS_HSCROLL,        // window style
		CW_USEDEFAULT,              // initial x position
		CW_USEDEFAULT,              // initial y position
		CW_USEDEFAULT,              // initial x size
		CW_USEDEFAULT,              // initial y size
		NULL,                       // parent window handle
		NULL,                       // window menu handle
		hInstance,                  // program instance handle
		NULL);                     // creation parameters

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);


	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HMENU		hMenu;
	HDC			hdc;
	PAINTSTRUCT	ps;
	TCHAR		szbuf[100] = { 0 };
	static HBRUSH		hBrush;
	static int idColor[3] = { WHITE_BRUSH,DKGRAY_BRUSH, BLACK_BRUSH };
	static int iSelection = ID_TEST_1;

	RECT		rect = { 200,200,500,400 };
	switch (message)
	{
		
		/*
	case WM_CREATE:
		hMenu = LoadMenu(hInst, MAKEINTRESOURCE(IDR_MENU1));
		SetMenu(hwnd, hMenu);
		return 0;
		*/

	case WM_PAINT:
		hdc = BeginPaint(hwnd, &ps);
		//hBrush = (HBRUSH)GetStockObject(BLACK_BRUSH);
		//hBrush = CreateSolidBrush(COLORREF(RGB(255, 0, 0)));
		//Rectangle(hdc, 200, 200, 500, 400);
		FillRect(hdc, &rect, hBrush);
		EndPaint(hwnd, &ps);
		return 0;
	case WM_COMMAND:
		hMenu = GetMenu(hwnd);
		switch (LOWORD(wParam))
		{
		case ID_FILE_OPEN:
			MessageBox(hwnd, L"Open", L"info", 0);
			return 0;

		case ID_FILE_EXIT:
			SendMessage(hwnd, WM_CLOSE, 0, 0);
			return 0;

		case ID_OTHER_ABOUT:
			MessageBox(hwnd, L"ZhuLin design", L"info", 0);
			return 0;
	
			/*
		case ID_TEST_1:
		case ID_TEST_2:
		case ID_TEST_3:
			CheckMenuItem(hMenu, iSelection, MF_UNCHECKED);
			iSelection = LOWORD(wParam);
			CheckMenuItem(hMenu, iSelection, MF_CHECKED);
			hBrush =(HBRUSH) GetStockObject(idColor[iSelection - ID_TEST_1]);
			InvalidateRect(hwnd, NULL, TRUE);
			return 0;
			*/
		
		}
		break;

		/*
	case WM_INITMENUPOPUP:
		EnableMenuItem((HMENU)wParam, ID_FILE_SAVE, MF_GRAYED);
		return 0;
		*/

	case WM_MENUCHAR:
		if (LOWORD(wParam)=='a')
		{
			SendMessage(hwnd, WM_COMMAND, ID_OTHER_ABOUT, 0);
		}
		return 0;

	case WM_MENUSELECT:
		/*
		ZeroMemory(szbuf, 100);
		hdc = GetDC(hwnd);
		wsprintf(szbuf, L"ID:%d   handle:%d", LOWORD(wParam),lParam);
		TextOut(hdc, 100, 100, szbuf, lstrlen(szbuf));
		ReleaseDC(hwnd, hdc);
		*/
		
		if (LOWORD(wParam)>=ID_TEST_1 && LOWORD(wParam)<=ID_TEST_3)
		{
			iSelection = LOWORD(wParam);
			hBrush = (HBRUSH)GetStockObject(idColor[iSelection - ID_TEST_1]);
			InvalidateRect(hwnd, NULL, TRUE);

		}
		
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
