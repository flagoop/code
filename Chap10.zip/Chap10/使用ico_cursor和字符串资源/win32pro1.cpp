﻿/*------------------------------------------
ICONDEMO.C -- Icon Demonstration Program
(c) Charles Petzold, 1998
------------------------------------------*/

#include <windows.h>
#include "resource.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ChildProc(HWND, UINT, WPARAM, LPARAM);
static HCURSOR		hCur;

static TCHAR	szMyCur[] = L"mucur";
TCHAR	 szChildName[] = TEXT("ChildWindow");


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	PSTR szCmdLine, int iCmdShow)
{
	TCHAR    szAppName[] = TEXT("IconDemo");
	HWND     hwnd;
	MSG      msg;
	WNDCLASS wndclass;
	static	TCHAR	szMyicon[] = L"myicon";
	static	TCHAR	szMyCur[] = L"mycur";

	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	//wndclass.hIcon = LoadIcon(hInstance,szMyicon);
	wndclass.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_1st));
	wndclass.hCursor = LoadCursor(NULL, IDC_CROSS);

	//wndclass.hCursor = LoadCursor(hInstance, szMyCur);
	wndclass.hbrBackground =(HBRUSH) GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = szAppName;

	if (!RegisterClass(&wndclass))
	{
		MessageBox(NULL, TEXT("This program requires Windows NT!"),
			szAppName, MB_ICONERROR);
		return 0;
	}

	//child wndclass
	wndclass.lpfnWndProc = ChildProc;
	wndclass.hCursor = LoadCursor(hInstance, szMyCur);
	wndclass.lpszClassName = szChildName;
	RegisterClass(&wndclass);

	hwnd = CreateWindow(szAppName, TEXT("Icon Demo"),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL);

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HICON hIcon;
	static int   cxIcon, cyIcon, cxClient, cyClient;
	HDC          hdc;
	HINSTANCE    hInstance;
	PAINTSTRUCT  ps;
	int          x, y;
	static TCHAR	szMyico[] = L"myicon";
	static TCHAR	szMycur[] = L"MYCUR";

	static HWND		hwndChild;


	switch (message)
	{
	case WM_CREATE:
		hInstance =(HINSTANCE) GetClassLong(hwnd, GWL_HINSTANCE);
		
		hwndChild = CreateWindow(szChildName, NULL, WS_BORDER | WS_VISIBLE|WS_CHILDWINDOW, 0, 0, 0, 0, hwnd, (HMENU)1,
			 NULL , NULL);

		//SetClassLong(hwndChild, GCL_HCURSOR,(LONG) LoadCursor(hInstance,szMyCur));
		return 0;

	case WM_SIZE:
		cxClient = LOWORD(lParam);
		cyClient = HIWORD(lParam);
		MoveWindow(hwndChild, 50, 50, 300, 300, true);
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}


LRESULT CALLBACK ChildProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	HANDLE		hFile;
	TCHAR		szBuffer[256] = { 0 }, szFormat[40] = { 0 };
	
	//使用字符串资源 将提示信息变成任何语言，这里使用的提示信息是中文，这个字符串资源是作为
	//一种外部资源调取的，比直接在源代码里写上 L"asjdflasjflsaj" 更加方便修改，只需要修改
	//这个外部资源里的内容，最后将源代码和这个资源文件链接一下就可以了，也加强了安全性。
	if (msg == WM_LBUTTONUP)
	{
		//hCur = LoadCursor((HINSTANCE)GetWindowLong(GetParent(hwnd), GWL_HINSTANCE), szMyCur);
		hFile=CreateFile(L"test.txt",GENERIC_READ,FILE_SHARE_READ,NULL,
			OPEN_EXISTING, 0, NULL);
		if (hFile==INVALID_HANDLE_VALUE)
		{
			LoadString((HINSTANCE)GetWindowLong(GetParent(hwnd), GWL_HINSTANCE), IDS_FILENOTFOUND,
				szFormat, 256);
			wsprintf(szBuffer, szFormat, L"test1.txt");
			MessageBox(hwnd, szBuffer, L"info", 0);
		}
		else
		{
			LoadString((HINSTANCE)GetWindowLong(GetParent(hwnd), GWL_HINSTANCE), IDS_FILEOPENED,
				szFormat, 256);
			wsprintf(szBuffer, szFormat, L"test.txt");
			MessageBox(hwnd,szBuffer, L"info", 0);
		}
	}
	
	return DefWindowProc ( hwnd, msg, wparam, lparam);
}
